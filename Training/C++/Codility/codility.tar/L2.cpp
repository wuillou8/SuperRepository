
// you can also use includes, for example:
// #include <algorithm>
int solution(vector<int> &A) {
    // write your code in C++98
    int NTot = 0;
    for ( size_t i = 0; i < A.size(); ++i ) {
        NTot += (i+1);
    } 
    for ( size_t i = 0; i < A.size(); ++i ) {
        NTot -= A[i];
    } 
    if( NTot == 0 ) {
        return 1;
    }
    else {
        return 0;
    }
}


    // write your code in C++98
    int NTot = 0;
    /*for ( size_t i = 0; i < A.size(); ++i ) {
        NTot += (i+1);
    } */
    for ( size_t i = 0; i < A.size(); ++i ) {
        NTot +=  (i+1) - A[i];
    } 
    if( NTot == 0 ) {
        return 1;
    }
    else {
        return 0;
    }
